# -*- coding: utf-8 -*-
from django.urls import path
from . import views

urlpatterns = [
    path("", views.starting_page, name = 'starting-page'),
    path("tutors", views.tutors, name = 'tutor-page'),
    path("tutors/<slug>", views.tutor_detail, name = 'tutor-detail-page')]
