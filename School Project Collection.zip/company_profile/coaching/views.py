from django.shortcuts import render
from .models import Tutor

# Create your views here.
def starting_page(request):
    latest_tutors = Tutor.objects.all().order_by("-date")[:3]
    return render(request, "coaching\index.html",
                  {"tutors":latest_tutors})

def tutors(request):
    all_tutors = Tutor.objects.all().order_by("-date")
    return render(request, "coaching/all-tutors.html",
                  {"all_tutors":all_tutors})


def tutor_detail(request, slug):
    identified_tutor = get_object_or_404(Tutor, slug = slug)
    return render(request, "coaching/tutor-detail.html",
                 {"tutor": identified_tutor})

