from django.apps import AppConfig


class CoachingConfig(AppConfig):
    name = 'coaching'
