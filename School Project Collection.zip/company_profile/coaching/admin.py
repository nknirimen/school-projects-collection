from django.contrib import admin
from .models import Tutor

class TutorAdmin(admin.ModelAdmin):
	list_filter = ("last_name", "date", )
	list_display = ("first_name", "last_name", "language", )
	prepopulated_fields = {"slug":("first_name", "last_name", )}

# Register your models here.
admin.site.register(Tutor, TutorAdmin)
